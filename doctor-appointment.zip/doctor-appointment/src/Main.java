
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        try {
            // Add a delay of 2 seconds as a welcome/loading screen
            System.out.println("Welcome to the Doctor Appointment Scheduler System...");
            Thread.sleep(1000); // Delay in milliseconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        LoadingAnimation();

        // Rest of your existing code...
        Scanner scanner = new Scanner(System.in);
        AppointmentScheduler scheduler = new AppointmentScheduler();

        while (true) {
            System.out.println("\nDoctor Appointment Scheduler System");
            System.out.println("\u001B[36m+----+--------------------------------+");
            System.out.println("| \u001B[33mNo \u001B[36m|          \u001B[33mMenu Option           \u001B[36m|");
            System.out.println("+----+--------------------------------+");
            System.out.println("| \u001B[33m 1  \u001B[36m| \u001B[37mSchedule Appointment           \u001B[36m|");
            System.out.println("| \u001B[33m 2  \u001B[36m| \u001B[37mDisplay Appointments           \u001B[36m|");
            System.out.println("| \u001B[33m 3  \u001B[36m| \u001B[37mCancel Appointment             \u001B[36m|");
            System.out.println("| \u001B[33m 4  \u001B[36m| \u001B[37mSearch Appointments by Doctor  \u001B[36m|");
            System.out.println("| \u001B[33m 5  \u001B[36m| \u001B[37mAdd Doctor's Information       \u001B[36m|");
            System.out.println("| \u001B[33m 6  \u001B[36m| \u001B[37mDisplay Doctors                \u001B[36m|");
            System.out.println("| \u001B[33m 7  \u001B[36m| \u001B[37mExit                           \u001B[36m|");
            System.out.println("+----+--------------------------------+");

            System.out.print("\u001B[37mEnter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:

                    System.out.print("Enter patient name: ");
                    String patientName = scanner.nextLine();
                    scheduler.displayDoctors();

                    System.out.print("Choose doctor by ID: ");
                    int doctorId = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character

                    System.out.print("Enter appointment date: ");
                    String date = scanner.nextLine();

                    scheduler.scheduleAppointment(patientName, doctorId, date);
                    break;

                case 2:

                    scheduler.displayAppointments();
                    scanner.nextLine();
                    break;

                case 3:

                    System.out.print("Enter appointment id to cancel: ");
                    int cancelDate = Integer.parseInt(scanner.nextLine());
                    scheduler.cancelAppointment(cancelDate);
                    scanner.nextLine();
                    break;



                case 4:

                    System.out.print("Enter doctor name to search: ");
                    String searchDoctor = scanner.nextLine();
                    scheduler.searchAppointmentsByDoctor(searchDoctor);
                    scanner.nextLine();
                    break;


                case 5:

                    System.out.print("Enter doctor name: ");
                    String newDoctorName = scanner.nextLine();

                    System.out.print("Enter doctor specialty: ");
                    String newDoctorSpecialty = scanner.nextLine();

                    scheduler.addDoctor(newDoctorName, newDoctorSpecialty);
                    scanner.nextLine();
                    break;
                case 6:

                    scheduler.displayDoctors();
                    scanner.nextLine();
                    break;
                case 7:

                    scheduler.closeConnection();
                    System.out.println("Exiting the system. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }



    public static void LoadingAnimation(){
        Thread animationThread = new Thread(() -> {
            try {
                String[] animationFrames = {
                        "\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A0\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A0\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A0\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A0\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A0\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A0",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1",
                        "\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1\u25A1"
                };
                int frameIndex = 0;

                while (!Thread.interrupted()) {
                    System.out.print("\r" + animationFrames[frameIndex]);
                    frameIndex = (frameIndex + 1) % animationFrames.length;
                    Thread.sleep(200); // Delay in milliseconds
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });

        System.out.print("Processing... ");
        animationThread.start();

        // Simulate some time-consuming task
        try {
            Thread.sleep(5000); // Delay in milliseconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        animationThread.interrupt(); // Stop the animation
        System.out.println("\rProcessing... Done!");

    }

}